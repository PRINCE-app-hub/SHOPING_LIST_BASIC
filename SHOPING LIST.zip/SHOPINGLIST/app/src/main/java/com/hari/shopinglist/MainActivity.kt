package com.hari.shopinglist

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Create
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.hari.shopinglist.ui.theme.SHOPINGLISTTheme

class MainActivity : ComponentActivity() {
    @OptIn(ExperimentalMaterial3Api::class)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            SHOPINGLISTTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    var SHOWDIALOGE by remember { mutableStateOf(false) }
                    var SItems by remember { mutableStateOf(listOf<ShopingList>()) }
                    var ItemName by remember { mutableStateOf("") }
                    var ItemQuantity by remember { mutableStateOf("") }

                    Column(
                        modifier = Modifier.fillMaxSize(),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        ButtonUI(onClick = { SHOWDIALOGE = true })
                        LazyColumn(
                            modifier = Modifier
                                .padding(8.dp)
                                .fillMaxSize()
                        ) {
                            items(SItems) { item ->
                                ShopingListItems_design(item)
                            }
                        }
                    }

                    if (SHOWDIALOGE) {
                        AlertDialog(
                            onDismissRequest = { SHOWDIALOGE = false },
                            confirmButton = {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(8.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Button(onClick = {
                                        if (ItemName.isNotBlank()) {
                                            val NewItem = ShopingList(
                                                id = SItems.size + 1,
                                                name = ItemName,
                                                quantity = ItemQuantity.toIntOrNull() ?: 1
                                            )
                                            SItems = SItems + NewItem
                                            SHOWDIALOGE = false
                                            ItemName = ""
                                            ItemQuantity = ""
                                        }
                                    }) {
                                        Text(text = "Add")
                                    }
                                    Button(onClick = { SHOWDIALOGE = false }) {
                                        Text(text = "Cancel")
                                    }
                                }
                            },
                            title = { Text("Add Shopping Items") },
                            text = {
                                Column {
                                    OutlinedTextField(
                                        value = ItemName,
                                        onValueChange = { ItemName = it },
                                        singleLine = true,
                                        modifier = Modifier.padding(8.dp)
                                    )
                                    OutlinedTextField(
                                        value = ItemQuantity,
                                        onValueChange = { ItemQuantity = it },
                                        singleLine = true,
                                        modifier = Modifier.padding(8.dp)
                                    )
                                }
                            }
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun ButtonUI(onClick: () -> Unit) {
    Button(
        onClick = onClick,
        colors = ButtonDefaults.buttonColors(containerColor = Color.Black),
        shape = RoundedCornerShape(80.dp),
        modifier = Modifier.padding(horizontal = 33.dp, vertical = 34.dp)
    ) {
        Text(text = "Add", color = Color.Cyan)
        Icon(
            imageVector = Icons.Default.Create,
            contentDescription = "For adding",
            modifier = Modifier.padding(start = 8.dp)
        )
    }
}

@Preview
@Composable
fun ButtonUIPreview() {
    SHOPINGLISTTheme {
        Surface(
            modifier = Modifier.fillMaxSize(),
            color = MaterialTheme.colorScheme.background
        ) {
            Column(
                modifier = Modifier.fillMaxSize(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                ButtonUI(onClick = {})
            }
        }
    }
}

data class ShopingList(val id: Int, val name: String, val quantity: Int, var isEditingBuffer: Boolean = true)

@Composable
fun ShopingListItems_design(item: ShopingList,
      onEditClick:()->Unit,
      onDeleteClick:()->Unit                      ) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .border(
                border = BorderStroke(4.dp, Color.Blue),
                shape = RoundedCornerShape(2.dp)
            )
    ) {
        Text(text = item.name, modifier = Modifier.padding(8.dp), color = Color.Cyan)
        Text(text = "Qty${item.quantity.toString()}", modifier = Modifier.padding(8.dp))
       Row(modifier = Modifier.padding(8.dp)) {
           IconButton(onClick = {onEditClick}) {
           }
       }
    }
}
