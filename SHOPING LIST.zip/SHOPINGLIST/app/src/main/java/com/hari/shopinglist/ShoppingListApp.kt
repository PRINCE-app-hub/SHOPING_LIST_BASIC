
package com.hari.shoppinglist

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Create
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
//import com.hari.shoppinglist.ui.theme.SHOPPINGLISTTheme

data class ShopingList(val id: Int, val name: String, val quantity: Int, var isEditingBuffer: Boolean = true)

@Preview(showBackground = true)
@Composable
fun ShoppingListAppAllInOne() {
    var SItems by remember { mutableStateOf(listOf<ShopingList>()) }
    var showDialog by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        ButtonUI(onClick = { showDialog = true })
        LazyColumn(
            modifier = Modifier
                .padding(8.dp)
                .fillMaxSize()
        ) {
            items(SItems) { item ->
                ShoppingListItem(item)
            }
        }
    }

    if (showDialog) {
        AlertDialog(
            onDismissRequest = { showDialog = false },
            title = { Text(text = "Add New Item") },
            text = { Text(text = "This is where you can add a new item to the list.") },
            confirmButton = {
                Button(onClick = { showDialog = false }) {
                    Text("OK")
                }
            },
            dismissButton = {
                Button(onClick = { showDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
fun ButtonUI(onClick: () -> Unit) {
    Button(
        onClick = onClick,
        colors = ButtonDefaults.buttonColors(containerColor = Color.Black),
        shape = RoundedCornerShape(80.dp),
        modifier = Modifier.padding(horizontal = 33.dp, vertical = 34.dp)
    ) {
        Text(text = "Add", color = Color.Cyan)
        Icon(
            imageVector = Icons.Default.Create,
            contentDescription = "For adding",
            modifier = Modifier.padding(start = 8.dp)
        )
    }
}

@Composable
fun ShoppingListItem(item: ShopingList) {
    Column(
        modifier = Modifier.padding(8.dp)
    ) {
        Text(text = "Name: ${item.name}")
        Text(text = "Quantity: ${item.quantity}")
    }
}

